package ru.obj;

public class TransferQueue {

    Transfer begining;
    Transfer ending;
    int count=0;

    void put(){
        System.out.println("создаем объект типа Трансфер");
        Transfer trans = new Transfer();

        if(count == 0){
            begining=trans;
        }
        if (ending!=null){
            ending.setNext(trans);
        }
        ending=trans;
        count++;

    }
    Transfer get(){
        System.out.println("Получаем объект типа Трансфер в порядке очереди");
        Transfer result;
        if(count<=0){
            result = null;
            System.out.println("Нет трансферов в очереди!!!");

        }
        if(count==1){
            result=begining;
        }
        else {
            result=ending.getNext();
        }

        count--;
        return result;

    }
}
