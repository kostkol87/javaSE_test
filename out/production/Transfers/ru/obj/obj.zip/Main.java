package ru.obj;

public class Main {
    public static void main(String[] args) {

        TransferQueue  tq = new TransferQueue();
        tq.put();
        System.out.println("В очереди осталость: " + tq.count);
        tq.put();
        System.out.println("В очереди осталость: " + tq.count);
        tq.put();
        System.out.println("В очереди осталость: " + tq.count);
        tq.put();
        System.out.println("В очереди осталость: " + tq.count);

        tq.get();
        System.out.println("В очереди осталость: " + tq.count);
        tq.get();
        System.out.println("В очереди осталость: " + tq.count);
        tq.get();
        System.out.println("В очереди осталость: " + tq.count);
        tq.get();
        System.out.println("В очереди осталость: " + tq.count);


    }
}
