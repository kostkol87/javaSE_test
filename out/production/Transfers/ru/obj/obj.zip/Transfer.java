package ru.obj;

import java.util.Random;

public class Transfer {
    private Transfer next;

    public Transfer getNext() {
        return next;
    }

    public void setNext(Transfer next) {
        this.next = next;
    }
}
